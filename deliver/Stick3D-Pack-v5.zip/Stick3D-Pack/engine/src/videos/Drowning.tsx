// "Instinctive Drowning Response" — 9:16 720x1280 30fps, 41.73 s (voice x1.25, silences trimmed).
// One continuous sunny pool (continuity of boy / father / lifeguard Maya), with a studio "glass tank" cutaway for the explainer.
// S1 crane over packed pool, cannonball  | S2 low-angle Maya, noise bubbles pop on "silence" | S3 she sees him -> swoop to the deep end
// S4 water-level: no wave, no yell, tape 3 m to the smiling father + thought bubble | S5 side-track dive from the tower
// S6 studio tank: title board + breath tokens fill BREATHE gauge, SCREAM 0% | S7 waterline split view: arms press down, mouth lifts
// S8 top-down calm -> pace clock band 20-60 s, he dips | S9 sprint swim, reach at 40, tow to wall, cough, cry | S10 father turns, crane out
import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame, Easing, Audio, staticFile } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Look } from "../style/puppet";
import { Person, Lights, Grade, seg, lerp, clamp, V3 } from "../style/kit";
import { Floor, Glow, Plant, Dust, Monitor, Lamp } from "../style/props";
import { Cam, Key, camAt, FaceGroup, hand, Arrow3D, Building, Bin, SpotCone } from "../style/extra";
import { Water, WaterFace, Glass, TilePlane, Splash, Torus, BeachBall, Palm, Lounger, Umbrella, GuardChair, PaceClock, PopSign, iconBadge, drawHand, drawYell, Thought, Gauge } from "../style/pool";
import { Captions } from "../Main";

const FPS = 30, LEAD = 6, TAIL = 8;
type Ctx = { t: number; f: number };
type Trans = "ghost" | "zoom" | "flash" | "whip";
type PoseIn = React.ComponentProps<typeof Person>["pose"];

/* ---------- scene wrapper (same 4 transitions as NvidiaV4) ---------- */
const Scene: React.FC<{ start: number; end: number; first?: boolean; trans?: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ start, end, first, trans = "ghost", bg, children }) => {
  const from = Math.round(start * FPS) - (first ? 0 : LEAD), dur = Math.round(end * FPS) - from + TAIL;
  return <Sequence from={from} durationInFrames={dur} layout="none"><Inner from={from} first={first} trans={trans} bg={bg} children={children} /></Sequence>;
};
const Inner: React.FC<{ from: number; first?: boolean; trans: Trans; bg: string; children: (c: Ctx) => React.ReactNode }> = ({ from, first, trans, bg, children }) => {
  const f = useCurrentFrame(), t = (f + from) / FPS;
  const k = first ? 1 : clamp(f / (LEAD + 2)), ke = Easing.out(Easing.cubic)(k);
  const sc = !first && trans === "zoom" ? lerp(1.35, 1, ke) : 1;
  const tx = !first && trans === "whip" ? (1 - ke) * 720 : 0, blur = !first && trans === "whip" ? (1 - ke) * 14 : 0;
  return (
    <AbsoluteFill style={{ opacity: first || trans === "flash" || trans === "whip" ? 1 : k, transform: `translateX(${tx}px) scale(${sc})`, background: bg, filter: `saturate(1.32) contrast(1.07) brightness(1.02)${blur > 0.2 ? ` blur(${blur.toFixed(1)}px)` : ""}` }}>
      <ThreeCanvas width={720} height={1280} camera={{ fov: 60, position: [0, 2, 8], near: 0.1, far: 220 }} gl={{ antialias: true }}>
        <color attach="background" args={[bg]} />{children({ t, f })}
      </ThreeCanvas>
      {!first && trans === "flash" ? <AbsoluteFill style={{ background: "#fff", opacity: 1 - clamp(f / 7) }} /> : null}
    </AbsoluteFill>
  );
};

/* ---------- cast ---------- */
const boyLook: Look = { skin: "#f7d4b5", body: "#ffe14d", outfit: "shirt", hair: "short", hairColor: "#6a3a1a", shoe: "#f7d4b5" };
const maya: Look = { skin: "#c98e62", body: "#e5233a", outfit: "shirt", hair: "bob", hairColor: "#1a1010", badge: "#ffd23a", shoe: "#c98e62" };
const dad: Look = { skin: "#f7d4b5", body: "#1f6fd8", outfit: "shirt", hair: "short", hairColor: "#6a3a1a", glasses: true, shoe: "#f7d4b5" };
const kidLooks: Look[] = [
  { skin: "#fbe3c8", body: "#ff4fa0", outfit: "shirt", hair: "bob", hairColor: "#5a3420" }, { skin: "#c98e62", body: "#2fd46a", outfit: "shirt", hair: "short", hairColor: "#1a1010" },
  { skin: "#8d5a3a", body: "#7c4dff", outfit: "shirt", hair: "short", hairColor: "#111" }, { skin: "#f6d6bd", body: "#ff7a29", outfit: "shirt", hair: "swept", hairColor: "#c47a2a" },
  { skin: "#e0b48c", body: "#2f8cff", outfit: "shirt", hair: "bob", hairColor: "#1a1010" }, { skin: "#fbe3c8", body: "#e53e3e", outfit: "shirt", hair: "short", hairColor: "#3b2a1a" },
  { skin: "#a86b45", body: "#00c2a8", outfit: "shirt", hair: "bob", hairColor: "#111" }, { skin: "#f1d0b0", body: "#9b5de5", outfit: "shirt", hair: "swept", hairColor: "#222" },
];
const cannonLook: Look = { skin: "#e0b48c", body: "#ff3b6b", outfit: "shirt", hair: "short", hairColor: "#1a1010" };
const adults: Look[] = [{ skin: "#f6d6bd", body: "#ffd23a", outfit: "shirt", hair: "bob", hairColor: "#c47a2a", glasses: true, shoe: "#e5233a" }, { skin: "#8d5a3a", body: "#22a867", outfit: "shirt", hair: "short", hairColor: "#111", hat: "#f2f2f2", shoe: "#2b3350" }];

/* ---------- pool geometry ---------- */
const PX0 = -7, PX1 = 7, PZ0 = -14, PZ1 = 4, WY = -0.25;
const floorY = (z: number) => (z >= 0 ? -1.1 : z <= -8 ? -3.6 : -1.1 - 2.5 * (-z / 8));
const HB = 2.4, B0: V3 = [1.0, 0, -8.6], BW: V3 = [6.15, 0, -8.6];
const HM = 3.4, MP: V3 = [-9.6, 3.08, -8.2];
const HD = 3.6, DP: V3 = [-2.0, floorY(-2.6), -2.6];
const CLK: V3 = [0, 3.6, -15.8];
const REACH = 34.56, TOW0 = 35.0, TOW1 = 35.85, COUGH = 36.48, CRY = 37.15;

/* drowning seconds shown on the pace clock (continuous story time) */
const drownSec = (t: number) => (t < 29.75 ? Math.max(0, (t - 7.6) * 0.45) : 10 + (t - 29.75) * 5.94);

const boyState = (t: number) => {
  const tw = seg(t, TOW0, TOW1, Easing.inOut(Easing.sin));
  const x = lerp(B0[0], BW[0], tw), z = B0[2], press = Math.sin(t * 5.2);
  let y = WY - 0.575 * HB + 0.05 * Math.sin(t * 5.2 + 0.6) + 0.03 * Math.sin(t * 8.3) + 0.04 * press;
  const dip = t < 33.45 ? 0 : t < 33.75 ? 0.42 * seg(t, 33.45, 33.75, Easing.inOut(Easing.sin)) : 0.42 - 0.2 * seg(t, 33.75, 34.15);
  if (t < REACH) y -= dip; else { const lift = seg(t, REACH, REACH + 0.4); y = lerp(y - 0.22, WY - 0.48 * HB + 0.02 * Math.sin(t * 3), lift); }
  return { x, y, z, press };
};
const mayaState = (t: number) => {
  // returns feet position, tilt, squash, swim flag
  if (t < 18.42) return { p: MP, tilt: 0, sq: 0, air: false, swim: false, under: false };
  if (t < 18.55) return { p: MP, tilt: -0.06, sq: -0.2 * seg(t, 18.42, 18.55, Easing.linear), air: false, swim: false, under: false };
  if (t < 19.7) { const u = (t - 18.55) / 1.15; return { p: [lerp(-9.6, -5.0, u), lerp(3.08, WY - 0.6, u) + 8.4 * u * (1 - u), lerp(-8.2, -8.0, u)] as V3, tilt: lerp(-0.12, 1.35, u ** 1.4), sq: 0.12, air: true, swim: false, under: false }; }
  if (t < 34.0) { const k = seg(t, 19.7, 20.05), g = clamp((t - 19.7) / 14.3); return { p: [lerp(-5.0, -4.4, g), lerp(WY - 0.6, -1.7, k), -8.0] as V3, tilt: lerp(1.35, 1.45, k), sq: 0, air: false, swim: false, under: true }; }
  if (t < REACH) { const k = seg(t, 34.0, 34.2), u = Easing.out(Easing.quad)(clamp((t - 34.0) / (REACH - 34.0))); return { p: [lerp(-4.4, 0.15, u), lerp(-1.7, WY - 0.66 * HM, k), -8.0] as V3, tilt: lerp(1.45, 0.3, k), sq: 0, air: false, swim: true, under: false }; }
  const tw = seg(t, TOW0, TOW1, Easing.inOut(Easing.sin));
  return { p: [lerp(0.15, 5.4, tw), WY - 0.66 * HM + 0.02 * Math.sin(t * 3.1), lerp(-8.0, -7.9, tw)] as V3, tilt: lerp(0.3, 0.05, seg(t, REACH, REACH + 0.4)) + (t > TOW0 && t < TOW1 ? 0.18 : 0), sq: 0, air: false, swim: false, under: false };
};

/* ---------- kids ---------- */
type Act = "splash" | "ballA" | "ballB" | "ring" | "jump" | "laugh";
const KIDS: { x: number; z: number; act: Act; ph: number }[] = [
  { x: -4.6, z: 2.2, act: "splash", ph: 0 }, { x: -2.3, z: 1.0, act: "ballA", ph: 1 }, { x: 2.4, z: 1.8, act: "ballB", ph: 2 }, { x: -5.0, z: -1.6, act: "ring", ph: 3 },
  { x: 4.6, z: 2.9, act: "splash", ph: 4 }, { x: 0.2, z: 3.0, act: "jump", ph: 5 }, { x: -1.0, z: 0.4, act: "splash", ph: 6 }, { x: 5.7, z: 0.3, act: "laugh", ph: 7 },
];
const HK = 2.5, BALL_T = 1.5;
const ballAt = (t: number): { p: V3; spin: number; n: number; u: number } => {
  const c = t / BALL_T, n = Math.floor(c), u = c - n; const A = KIDS[1], B = KIDS[2];
  const a: V3 = [A.x, floorY(A.z) + 0.72 * HK + 0.35, A.z], b: V3 = [B.x, floorY(B.z) + 0.72 * HK + 0.35, B.z];
  const [s, e] = n % 2 ? [b, a] : [a, b];
  return { p: [lerp(s[0], e[0], u), lerp(s[1], e[1], u) + 9.6 * u * (1 - u), lerp(s[2], e[2], u)], spin: t * 4, n, u };
};
const CB0 = 2.0, CB1 = 2.5; // cannonball kid
const kidNode = (i: number, t: number, f: number) => {
  const k = KIDS[i], fy = floorY(k.z), ph = t * 6 + k.ph;
  let y = fy; const pose: PoseIn = { mood: Math.sin(t * 0.9 + i) > -0.2 ? "laugh" : "grin", lookX: Math.sin(t * 0.8 + i) * 0.7 };
  if (k.act === "splash" || k.act === "laugh") {
    pose.armR = [0.3 + 0.05 * Math.sin(ph), 0.36 + 0.14 * Math.max(0, Math.sin(ph))]; pose.armL = [-0.3 - 0.05 * Math.sin(ph + 1.7), 0.36 + 0.14 * Math.max(0, Math.sin(ph + 1.7))];
    if (k.act === "laugh") { pose.arms = "chest"; pose.armK = 1; pose.armR = undefined; pose.armL = undefined; pose.squash = 0.04 * Math.sin(t * 14); }
  }
  if (k.act === "jump") { const jp = (t * 1.25 + k.ph * 0.1) % 1; y = fy + Math.sin(jp * Math.PI) * 0.5; pose.squash = jp < 0.08 || jp > 0.92 ? -0.12 : 0.08; pose.arms = "up"; pose.armK = 1; pose.air = y > fy + 0.05 ? 1 : 0; }
  if (k.act === "ring") { y = WY - 0.4 * HK + 0.05 * Math.sin(t * 2 + i); pose.armR = [0.36, 0.42]; pose.armL = [-0.36, 0.42]; pose.mood = "grin"; }
  if (k.act === "ballA" || k.act === "ballB") {
    const b = ballAt(t), mine = (b.n % 2 === 0) === (k.act === "ballA"), throwing = mine && b.u < 0.2, catching = !mine && b.u > 0.7;
    if (throwing || catching) { pose.arms = "up"; pose.armK = throwing ? 1 - seg(b.u, 0.08, 0.2) : seg(b.u, 0.7, 0.85); }
    else { pose.armR = [0.3, 0.38 + 0.08 * Math.max(0, Math.sin(ph))]; pose.armL = [-0.3, 0.38]; }
    pose.lookX = k.act === "ballA" ? 1 : -1;
  }
  return <Person key={"k" + i} p={[k.x, y, k.z]} sy={fy} h={HK} look={kidLooks[i]} f={f + i * 7} pose={pose} />;
};
const cannonState = (t: number) => {
  const D: V3 = [8.4, 0, 1.2], L: V3 = [5.0, 0, 1.2];
  if (t < CB0) return { p: D, sq: t > 1.82 ? -0.2 * seg(t, 1.82, CB0, Easing.linear) : 0, air: 0, arms: "down" as const, sy: 0, mood: "grin" as const };
  if (t < CB1) { const u = (t - CB0) / (CB1 - CB0); return { p: [lerp(D[0], L[0], u), lerp(0, WY - 0.9, u) + 6.0 * u * (1 - u), L[2]] as V3, sq: 0.06, air: 1, arms: "chest" as const, sy: u < 0.25 ? 0 : floorY(L[2]), mood: "laugh" as const }; }
  const up = seg(t, CB1 + 0.25, CB1 + 0.7, Easing.out(Easing.back(1.6)));
  return { p: [L[0], lerp(WY - 1.6, floorY(L[2]), up), L[2]] as V3, sq: 0, air: 0, arms: "up" as const, sy: floorY(L[2]), mood: "laugh" as const };
};

/* ---------- the pool world (all pool scenes) ---------- */
type Over = { boy?: PoseIn; maya?: PoseIn; dad?: PoseIn; hideMaya?: boolean };
const PoolWorld: React.FC<{ t: number; f: number; calm?: number; clock?: { band?: [number, number]; bandK?: number; warn?: number }; over?: Over }> = ({ t, f, calm = 0, clock = {}, over = {} }) => {
  const bs = boyState(t), ms = mayaState(t), cb = cannonState(t), ball = ballAt(t);
  const rings: [number, number, number][] = [[5.0, 1.2, CB1], [-3.8, -8.0, 19.6], [0.4, -8.3, REACH]];
  for (let k = 0; k < 3; k++) { const t0 = Math.floor(t / 0.8) * 0.8 - k * 0.8; if (t0 < REACH) { const b = boyState(t0); rings.push([b.x, b.z, t0]); } }
  KIDS.forEach((kd, i) => { const per = 1.1 + i * 0.07, t0 = Math.floor((t + i * 0.3) / per) * per - i * 0.3; rings.push([kd.x, kd.z, t0]); });
  if (t > 34 && t < 36.2) for (let k = 0; k < 5; k++) { const t0 = Math.floor(t / 0.22) * 0.22 - k * 0.22; if (t0 > 34) { const m = mayaState(t0); rings.push([m.p[0], m.p[2], t0]); } }
  // boy pose (overridable)
  const pressArm = (s: number): [number, number] => [s * 0.37, 0.47 - 0.05 * Math.sin(t * 5.2 + (s > 0 ? 0 : 0.5))];
  const boyBase: PoseIn = t < REACH ? { mood: "gasp", headUp: 1, armR: pressArm(1), armL: pressArm(-1), lookX: 0, walk: t * 4, speed: 0.35 }
    : t < TOW1 ? { mood: "worry", headUp: 1 - seg(t, REACH, REACH + 0.5), arms: "chest", armK: seg(t, REACH, REACH + 0.3), nerv: 0.3 }
    : { mood: t < COUGH ? "worry" : t < CRY ? "cough" : "cry", armR: [0.42, 0.62], armL: [0.18, 0.6], nerv: t > CRY ? 0.35 : 0.2, squash: t > COUGH && t < CRY ? -0.11 * Math.max(0, Math.sin((t - COUGH) * 13)) : 0, tilt: t > COUGH && t < CRY ? 0.08 * Math.max(0, Math.sin((t - COUGH) * 13)) : 0 };
  const mayaBase: PoseIn = ms.air ? { mood: "angry", arms: "up", armK: 1, squash: ms.sq, tilt: ms.tilt, air: 1 }
    : ms.under ? { mood: "angry", arms: "up", armK: 1, tilt: ms.tilt }
    : ms.swim ? { mood: "angry", tilt: ms.tilt, armR: [0.3 + 0.16 * Math.cos(t * 9), 0.62 + 0.2 * Math.sin(t * 9)], armL: [-0.3 + 0.16 * Math.cos(t * 9 + Math.PI), 0.62 + 0.2 * Math.sin(t * 9 + Math.PI)], armRK: 1, armLK: 1 }
    : t > REACH ? { mood: "worry", tilt: ms.tilt, armR: [0.42, 0.5], armRK: 1, lookX: 1 }
    : { mood: "deadpan", squash: ms.sq, tilt: ms.tilt };
  const mayaSy = ms.air ? (ms.p[0] < -7.25 ? 0 : WY) : ms.p === MP ? MP[1] : floorY(ms.p[2]);
  return (<>
    <Lights warm="#fff0cc" />
    {/* sky + sun + skyline */}
    <CanvasPlane p={[0, 26, -75]} s={[230, 90]} px={[512, 200]} draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#2f8fff"); g.addColorStop(0.75, "#9fdcff"); g.addColorStop(1, "#d9f4ff"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "rgba(255,255,255,.95)"; for (const [x, y, r] of [[90, 60, 26], [120, 54, 30], [150, 62, 22], [330, 40, 24], [360, 34, 30], [395, 42, 22], [250, 90, 18], [270, 86, 22]] as [number, number, number][]) { c.beginPath(); c.arc(x + Math.sin(t * 0.05) * 6, y, r, 0, 7); c.fill(); } }} />
    <Glow p={[-24, 32, -72]} r={10} color="rgba(255,240,170,1)" o={0.9} /><Ball p={[-24, 32, -73]} r={3.2} color="#fff3a0" ink={0} />
    <Building p={[0, 0, -27]} s={[34, 9, 5]} color="#f6cf9a" face="+z" seed={3} lit={0.12} trim="#c0643a" />
    <Building p={[-24, 0, -32]} s={[11, 15, 6]} color="#e8a07a" face="+z" seed={7} lit={0.1} /><Building p={[24, 0, -32]} s={[11, 13, 6]} color="#9ec5e8" face="+z" seed={9} lit={0.1} />
    {/* deck */}
    <Surface p={[-23.75, 0, -7.5]} s={[32.5, 75]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#f4e6cf" b="#ead9bd" unit={1.4} />
    <Surface p={[23.75, 0, -7.5]} s={[32.5, 75]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#f4e6cf" b="#ead9bd" unit={1.4} />
    <Surface p={[0, 0, -29.75]} s={[15, 30.5]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#f4e6cf" b="#ead9bd" unit={1.4} />
    <Surface p={[0, 0, 17.25]} s={[15, 25.5]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#f4e6cf" b="#ead9bd" unit={1.4} />
    <Box p={[-7.25, 0.06, -5]} s={[0.5, 0.12, 19]} color="#ffffff" line={2} /><Box p={[7.25, 0.06, -5]} s={[0.5, 0.12, 19]} color="#ffffff" line={2} />
    <Box p={[0, 0.06, -14.25]} s={[15, 0.12, 0.5]} color="#ffffff" line={2} /><Box p={[0, 0.06, 4.25]} s={[15, 0.12, 0.5]} color="#ffffff" line={2} />
    {/* basin: floor (shallow, slope, deep) + walls + waterline band */}
    <TilePlane p={[0, -1.1, 2]} s={[14, 4]} rot={[-Math.PI / 2, 0, 0]} t={t} stripe="#1d4fa0" />
    <TilePlane p={[0, -2.35, -4]} s={[14, 8.38]} rot={[-Math.PI / 2 - 0.3029, 0, 0]} t={t} stripe="#1d4fa0" />
    <TilePlane p={[0, -3.6, -11]} s={[14, 6]} rot={[-Math.PI / 2, 0, 0]} t={t} stripe="#1d4fa0" a="#3fb6e6" b="#36a8dc" />
    <TilePlane p={[0, -1.8, -14]} s={[14, 3.6]} t={t} caustic={0.6} a="#38aede" b="#30a2d6" />
    <TilePlane p={[0, -0.55, 4]} s={[14, 1.1]} rot={[0, Math.PI, 0]} t={t} caustic={0.4} a="#38aede" b="#30a2d6" />
    <TilePlane p={[-7, -1.8, -5]} s={[18, 3.6]} rot={[0, Math.PI / 2, 0]} t={t} caustic={0.6} a="#38aede" b="#30a2d6" />
    <TilePlane p={[7, -1.8, -5]} s={[18, 3.6]} rot={[0, -Math.PI / 2, 0]} t={t} caustic={0.6} a="#38aede" b="#30a2d6" />
    <Box p={[0, -0.1, -13.97]} s={[14, 0.22, 0.04]} color="#1d3f8a" line={1} /><Box p={[0, -0.1, 3.97]} s={[14, 0.22, 0.04]} color="#1d3f8a" line={1} />
    <Box p={[-6.97, -0.1, -5]} s={[0.04, 0.22, 18]} color="#1d3f8a" line={1} /><Box p={[6.97, -0.1, -5]} s={[0.04, 0.22, 18]} color="#1d3f8a" line={1} />
    {/* rope of floats: shallow | deep */}
    {Array.from({ length: 30 }, (_, i) => <Ball key={"r" + i} p={[-6.8 + i * 0.47, WY + 0.08 + 0.02 * Math.sin(t * 2 + i * 0.7), -6]} r={0.14} color={i % 2 ? "#ffffff" : "#e5233a"} ink={0.03} />)}
    {/* deep-end ladder, diving board, pace clock */}
    {[-11.6, -12.4].map((z) => <React.Fragment key={z}><Cyl p={[-6.55, -0.4, z]} rt={0.06} h={2.6} color="#d8dde8" line={1} /><Box p={[-6.95, 0.9, z]} s={[0.8, 0.1, 0.1]} color="#d8dde8" line={1} /><Cyl p={[-7.35, 0.45, z]} rt={0.06} h={0.9} color="#d8dde8" line={1} /></React.Fragment>)}
    {[-0.3, -0.9, -1.5].map((y) => <Box key={y} p={[-6.6, y, -12]} s={[0.12, 0.08, 0.8]} color="#d8dde8" line={1} />)}
    <Box p={[3.6, 0.35, -15.6]} s={[1.2, 0.7, 1.6]} color="#2f8cff" /><Box p={[3.6, 0.78, -13.7]} s={[0.9, 0.12, 3.6]} color="#ffffff" />
    {[-1.4, 1.4].map((x) => <Cyl key={x} p={[x, 1.25, -15.95]} rt={0.1} h={2.5} color="#2b3350" line={2} />)}
    <PaceClock p={CLK} r={2.1} sec={drownSec(t)} band={clock.band} bandK={clock.bandK} warn={clock.warn} />
    {/* lifeguard tower */}
    <GuardChair p={[MP[0], 0, MP[2]]} rotY={Math.PI / 2} />
    {/* deck dressing */}
    {[[-12, -2.5, "#2fd46a"], [-12, 0.5, "#ff4fa0"], [-12, 3.5, "#ffd23a"]].map(([z0, z1, c], i) => <Lounger key={"l" + i} p={[z0 as number, 0, z1 as number]} rotY={Math.PI / 2} towel={c as string} />)}
    {[[12, -6, "#2f8cff"], [12, -3, "#ff7a29"]].map(([x, z, c], i) => <Lounger key={"m" + i} p={[x as number, 0, z as number]} rotY={-Math.PI / 2} towel={c as string} />)}
    <Umbrella p={[-13.8, 0, -1]} color="#ff5a3a" /><Umbrella p={[-13.8, 0, 2.6]} color="#2fd46a" /><Umbrella p={[13.8, 0, -4.5]} color="#7c4dff" />
    <Palm p={[-13, 0, -16]} rotY={0.4} /><Palm p={[13.5, 0, -15]} rotY={2.6} h={7.6} /><Palm p={[-15, 0, 5]} rotY={-0.6} h={6.4} /><Palm p={[15, 0, 6]} rotY={3.4} />
    <Plant p={[-8.8, 0, 6]} s={1.2} /><Plant p={[8.8, 0, 6]} s={1.2} /><Plant p={[-8.8, 0, -16.5]} s={1.3} /><Plant p={[8.8, 0, -16.5]} s={1.3} />
    {/* fence */}
    {Array.from({ length: 21 }, (_, i) => <Box key={"fp" + i} p={[-20 + i * 2, 0.9, -20]} s={[0.12, 1.8, 0.12]} color="#ffffff" line={1} />)}
    <Box p={[0, 1.7, -20]} s={[40, 0.12, 0.12]} color="#ffffff" line={1} /><Box p={[0, 0.9, -20]} s={[40, 0.1, 0.1]} color="#ffffff" line={1} />
    {/* signs, depth marks, life ring, cooler, bin, floats */}
    <group position={[9.2, 0, -12]}><Cyl p={[0, 1.2, 0]} rt={0.07} h={2.4} color="#2b3350" line={2} /><CanvasPlane p={[0, 2.5, 0.05]} s={[2.0, 0.9]} px={[400, 180]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#ffffff"; c.fillRect(0, 0, W, H); c.fillStyle = "#e5233a"; c.fillRect(0, 0, W, 44); c.fillStyle = "#fff"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.fillText("CAUTION", W / 2, 34); c.fillStyle = INK; c.font = "900 64px Inter, Arial"; c.fillText("DEEP END", W / 2, 118); c.font = "800 34px Inter, Arial"; c.fillText("3 m", W / 2, 162); }} /></group>
    <group position={[-8.9, 0, -3]}><Cyl p={[0, 1.0, 0]} rt={0.07} h={2.0} color="#2b3350" line={2} /><CanvasPlane p={[0, 2.2, 0.05]} s={[1.8, 0.8]} px={[360, 160]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#2f8cff"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 58px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("NO RUNNING", W / 2, H / 2 + 3); }} /></group>
    {[[-8.1, -11, "3 m"], [8.1, -11, "3 m"], [-8.1, 2.2, "1.2 m"], [8.1, 2.2, "1.2 m"]].map(([x, z, s], i) => <CanvasPlane key={"d" + i} p={[x as number, 0.02, z as number]} rot={[-Math.PI / 2, 0, 0]} s={[1.4, 0.7]} px={[280, 140]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#1d3f8a"; c.font = "900 92px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(s as string, W / 2, H / 2 + 4); }} />)}
    <group position={[9.0, 0, -8]}><Cyl p={[0, 1.0, 0]} rt={0.07} h={2.0} color="#2b3350" line={2} /><Torus p={[0, 1.7, 0.12]} R={0.55} r={0.16} color="#ff3b2b" rot={[0, 0, 0]} /></group>
    <Box p={[11.4, 0.4, 3]} s={[1.2, 0.8, 0.8]} color="#2f8cff" /><Box p={[11.4, 0.86, 3]} s={[1.3, 0.14, 0.9]} color="#ffffff" line={2} /><Bin p={[-9.5, 0, 8]} color="#2f8cff" />
    <Box p={[-3, WY + 0.06, -3.4]} s={[0.9, 0.1, 0.6]} color="#ffd23a" line={2} rot={[0, 0.4, 0]} /><Box p={[6.0, WY + 0.06, -2.4]} s={[0.9, 0.1, 0.6]} color="#2fd46a" line={2} rot={[0, -0.3, 0]} />
    <Torus p={[-5.6, WY + 0.08, -4.0 + 0.1 * Math.sin(t * 0.6)]} R={0.6} r={0.2} color="#ff4fa0" />
    {/* bunting */}
    <CanvasPlane p={[0, 6.6, -2]} s={[16, 1.2]} px={[960, 72]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); c.moveTo(0, 6); c.quadraticCurveTo(W / 2, 34, W, 6); c.stroke(); const cols = ["#e5233a", "#ffd23a", "#2f8cff", "#2fd46a", "#ff7a29"]; for (let i = 0; i < 24; i++) { const x = 20 + i * 39.2, y = 6 + 28 * (1 - ((x / W) * 2 - 1) ** 2); c.fillStyle = cols[i % 5]; c.beginPath(); c.moveTo(x - 14, y); c.lineTo(x + 14, y); c.lineTo(x + Math.sin(t * 3 + i) * 2, y + 32); c.closePath(); c.fill(); c.stroke(); } }} />
    {/* deck adults chatting */}
    <Person p={[10.4, 0, -0.6]} h={3.4} look={adults[0]} f={f} pose={{ mood: Math.sin(t * 0.7) > 0 ? "laugh" : "smile", armR: [0.24, 0.5], lookX: 1 }} />
    <FaceGroup p={[10.4, 0, -0.6]}><Cyl p={hand(3.4, [0.24, 0.5], 0, false, 0.1).map((v, j) => (j === 1 ? v + 0.15 : v)) as V3} rt={0.12} h={0.36} color="#ff7a29" line={2} /></FaceGroup>
    <Person p={[11.6, 0, 0.3]} h={3.6} look={adults[1]} f={f + 40} pose={{ mood: "grin", lookX: -1, arms: "shrug", armK: 0.5 + 0.5 * Math.sin(t * 1.3) }} />
    {/* kids, ball, cannonball kid */}
    {KIDS.map((_, i) => kidNode(i, t, f))}
    <BeachBall p={ball.p} spin={ball.spin} />
    <Person p={cb.p} sy={cb.sy} h={HK} look={cannonLook} f={f} pose={{ mood: cb.mood, squash: cb.sq, air: cb.air, arms: cb.arms, armK: 1 }} shadow={cb.air === 0 || cb.p[0] > 7.3} />
    <Splash p={[5.0, WY, 1.2]} t={t} t0={CB1} power={1.4} n={22} />
    {KIDS.map((kd, i) => (kd.act === "splash" ? <Splash key={"ks" + i} p={[kd.x + (Math.floor(t / 0.5 + i) % 2 ? 0.7 : -0.7), WY, kd.z + 0.2]} t={t} t0={Math.floor(t / 0.5 + i * 0.3) * 0.5 - i * 0.15} power={0.32} n={6} /> : null))}
    {/* the boy, the father, the lifeguard */}
    <Person p={[bs.x, bs.y, bs.z]} sy={floorY(bs.z)} h={HB} look={boyLook} f={f} pose={{ ...boyBase, ...(over.boy ?? {}) }} />
    <Person p={DP} sy={DP[1]} h={HD} look={dad} f={f + 20} pose={{ mood: "smile", lookX: 0.6, armR: [0.22, 0.42], armL: [-0.22, 0.42], ...(over.dad ?? {}) }} />
    {!over.hideMaya ? <Person p={ms.p} sy={mayaSy} h={HM} look={maya} f={f + 11} pose={{ ...mayaBase, ...(over.maya ?? {}) }} shadow={!ms.under} /> : null}
    <Splash p={[-3.8, WY, -8.0]} t={t} t0={19.58} power={1.5} n={24} />
    <Splash p={[0.5, WY, -8.2]} t={t} t0={REACH} power={0.7} n={12} />
    <Water t={t} x0={PX0} x1={PX1} z0={PZ0} z1={PZ1} y={WY} rings={rings} calm={calm} />
  </>);
};

/* =================== S1 0 – 4.05  "The pool is packed. Kids are screaming, splashing, laughing." =================== */
const K1: Key[] = [
  { t: 0, pos: [1.5, 17, 20], look: [0, -1, -5], fov: 58 },
  { t: 1.6, pos: [3.6, 9, 15], look: [1.0, -0.5, -2], fov: 58 },
  { t: 2.6, pos: [7.0, 4.0, 10.5], look: [3.8, 0.2, 0.5], fov: 56 },
  { t: 4.35, pos: [4.2, 2.6, 10.5], look: [0.2, 0.4, -2.0], fov: 56 },
];
const S1 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={K1} impacts={[[CB1, 0.012]]} />
  <PoolWorld t={t} f={f} over={{ maya: { mood: "deadpan", lookX: Math.sin(t * 1.2) } }} />
</>);

/* =================== S2 4.05 – 7.62  "Lifeguard Maya isn't listening for noise. She's watching for silence." =================== */
const K2: Key[] = [
  { t: 3.85, pos: [-3.6, 2.2, -5.0], look: [-9.6, 4.2, -8.4], fov: 54 },
  { t: 5.5, pos: [-4.4, 2.6, -5.6], look: [-9.6, 4.4, -8.3], fov: 52 },
  { t: 6.85, pos: [-5.6, 3.4, -6.4], look: [-9.6, 4.7, -8.2], fov: 48 },
  { t: 7.9, pos: [-6.4, 4.6, -6.9], look: [-9.6, 4.9, -8.2], fov: 48 },
];
const NOISE = ["AAAH!", "SPLASH!", "HAHA!", "WHEE!", "!!!", "YAY!", "MARCO!"];
const NOFF: [number, number][] = [[-0.8, 1.15], [0.8, 0.95], [-0.85, -0.35], [0.85, -0.55], [-0.45, 1.95], [0.55, 2.05], [0.05, 2.65]];
// point at distance-fraction k from head toward the camera, offset in screen right/up
const camSpace = (head: V3, cam: V3, k: number, ox: number, oy: number): V3 => {
  const fx = head[0] - cam[0], fy = head[1] - cam[1], fz = head[2] - cam[2], L = Math.hypot(fx, fy, fz); const f = [fx / L, fy / L, fz / L];
  const r = [-f[2], 0, f[0]], rl = Math.hypot(r[0], r[2]); r[0] /= rl; r[2] /= rl; const u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
  return [head[0] - fx * k + r[0] * ox + u[0] * oy, head[1] - fy * k + r[1] * ox + u[1] * oy, head[2] - fz * k + r[2] * ox + u[2] * oy];
};
const S2 = ({ t, f }: Ctx) => {
  const sil = seg(t, 6.82, 7.08, Easing.in(Easing.back(2)));
  const visor = seg(t, 6.3, 6.55), scan = Math.sin((t - 4) * 2.1);
  return (<>
    <Cam t={t} keys={K2} fovKick={[6.87]} />
    <PoolWorld t={t} f={f} over={{ maya: { mood: t < 6.3 ? "deadpan" : "worry", lookX: t < 6.3 ? scan : 0.8 + 0.15 * Math.sin(t * 3), hunch: 0.5 * visor, armR: t > 6.3 ? [0.1, 0.8] : undefined, armRK: visor } }} />
    {NOISE.map((w, i) => { const k0 = seg(t, 4.12 + i * 0.2, 4.34 + i * 0.2, Easing.out(Easing.back(2.6))) * (1 - sil); const o = NOFF[i];
      return <PopSign key={w} p={camSpace([MP[0], MP[1] + 2.0, MP[2]], camAt(t, K2).pos, 0.35, o[0], o[1] + Math.sin(f * 0.15 + i) * 0.06)} s={0.85} k={k0} draw={(c, W, H) => {
        c.save(); c.translate(W / 2, H / 2); c.rotate(Math.sin(i * 2.1) * 0.25); c.fillStyle = ["#ffd23a", "#ffffff", "#ff7aa8", "#7fe8ff", "#ffd23a", "#b8ff6a", "#ffffff"][i]; c.strokeStyle = INK; c.lineWidth = 8;
        c.beginPath(); for (let q = 0; q < 24; q++) { const a = q / 24 * Math.PI * 2, r = q % 2 ? W * 0.3 : W * 0.44; q ? c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.62) : c.moveTo(Math.cos(a) * r, Math.sin(a) * r * 0.62); } c.closePath(); c.fill(); c.stroke();
        c.fillStyle = "#e5233a"; c.font = `900 ${w.length > 5 ? 44 : 56}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.lineWidth = 6; c.strokeStyle = INK; c.strokeText(w, 0, 3); c.fillText(w, 0, 3); c.restore(); }} />; })}
    {/* "silence": a soft ring of quiet around her eyes */}
    {t > 6.87 ? <Glow p={[MP[0] + 0.3, MP[1] + 2.05, MP[2] + 0.3]} r={1.6 * seg(t, 6.87, 7.3)} color="rgba(200,240,255,1)" o={0.35} /> : null}
  </>);
};

/* =================== S3 7.62 – 13.1  "Then she sees him. A boy near the deep end, upright, head tilted back, mouth bobbing right at the surface." =================== */
const K3: Key[] = [
  { t: 7.42, pos: [-6.5, 4.6, -6.9], look: [-9.6, 4.9, -8.2], fov: 48 },
  { t: 8.3, pos: [-6.2, 4.7, -6.5], look: [-9.6, 4.9, -8.2], fov: 50 },
  { t: 9.1, pos: [-6.6, 6.2, -9.8], look: [0.6, -0.6, -8.6], fov: 52 },
  { t: 10.3, pos: [-3.4, 3.6, -7.6], look: [1.0, -0.2, -8.6], fov: 50 },
  { t: 11.7, pos: [-1.2, 1.9, -6.3], look: [1.0, 0.3, -8.6], fov: 50 },
  { t: 13.35, pos: [-0.3, 1.0, -6.7], look: [1.0, 0.15, -8.6], fov: 44 },
];
const S3 = ({ t, f }: Ctx) => {
  const sees = t >= 8.25, jolt = t > 8.25 && t < 8.45 ? 0.1 * Math.sin((t - 8.25) / 0.2 * Math.PI) : 0;
  const bs = boyState(t), head: V3 = [bs.x, bs.y + HB * 0.6, bs.z];
  const upK = seg(t, 10.04, 10.35), tiltK = seg(t, 10.5, 10.85), surfK = seg(t, 12.5, 12.8, Easing.out(Easing.back(2)));
  return (<>
    <Cam t={t} keys={K3} />
    <PoolWorld t={t} f={f} over={{ maya: { mood: sees ? "shock" : "deadpan", lookX: sees ? 1 : Math.sin((t - 7) * 2.1), squash: jolt, arms: t > 8.55 ? "point" : undefined, armK: seg(t, 8.55, 8.8), nerv: sees ? 0.3 : 0 },
      boy: { headUp: t < 10.5 ? 0.35 : 0.35 + 0.65 * tiltK } }} />
    {/* callouts: plumb line (upright), tilt arc (head back), surface ring */}
    {upK > 0 ? <CanvasPlane p={[bs.x - 0.02, bs.y + HB * 0.5, bs.z + 0.05]} s={[0.25, HB * 1.25 * upK + 0.01]} px={[32, 256]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#ffd23a"; for (let y = 0; y < H; y += 26) c.fillRect(W * 0.3, y, W * 0.4, 14); }} /> : null}
    <PopSign p={[head[0] + 0.55, head[1] + 0.15, head[2] + 0.1]} s={0.9} k={tiltK * (1 - seg(t, 12.3, 12.5))} draw={(c, W, H) => { c.strokeStyle = INK; c.lineWidth = 22; c.beginPath(); c.arc(W * 0.3, H * 0.62, W * 0.42, -1.2, 0.1); c.stroke(); c.strokeStyle = "#ffd23a"; c.lineWidth = 12; c.stroke(); c.fillStyle = "#ffd23a"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.moveTo(W * 0.42, H * 0.12); c.lineTo(W * 0.22, H * 0.2); c.lineTo(W * 0.44, H * 0.34); c.closePath(); c.fill(); c.stroke(); }} />
    {surfK > 0 ? <CanvasPlane p={[bs.x, WY + 0.04, bs.z]} rot={[-Math.PI / 2, 0, 0]} s={[1.6 * surfK + 0.01, 1.6 * surfK + 0.01]} px={[256, 256]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = `rgba(255,210,58,${0.6 + 0.4 * Math.sin(f * 0.5)})`; c.lineWidth = 16; c.beginPath(); c.arc(W / 2, H / 2, W * 0.4, 0, 7); c.stroke(); }} /> : null}
  </>);
};

/* =================== S4 13.1 – 18.68  "He isn't waving. He isn't yelling. His father is three meters away, smiling, because it looks like his son is just playing." =================== */
const K4: Key[] = [
  { t: 12.9, pos: [3.3, 0.5, -12.4], look: [1.0, 0.0, -8.6], fov: 52 },
  { t: 14.5, pos: [3.0, 0.55, -12.0], look: [1.0, 0.05, -8.6], fov: 50 },
  { t: 15.55, pos: [4.4, 2.9, -13.2], look: [-0.6, -0.5, -5.2], fov: 56 },
  { t: 16.8, pos: [1.6, 2.2, -9.4], look: [-1.6, 0.0, -3.0], fov: 54 },
  { t: 18.95, pos: [0.6, 1.9, -8.2], look: [-1.8, 0.6, -2.8], fov: 50 },
];
const S4 = ({ t, f }: Ctx) => {
  const bs = boyState(t), fade = 1 - seg(t, 14.7, 15.0);
  const waveK = seg(t, 13.43, 13.66, Easing.out(Easing.back(2.4))) * fade, yellK = seg(t, 14.25, 14.48, Easing.out(Easing.back(2.4))) * fade;
  const tapeK = seg(t, 15.37, 15.85, Easing.inOut(Easing.cubic)) * (1 - seg(t, 16.45, 16.75, Easing.inOut(Easing.cubic))), labK = seg(t, 15.62, 15.85, Easing.out(Easing.back(2.5))) * (1 - seg(t, 16.5, 16.75));
  const A: V3 = [bs.x, WY + 0.05, bs.z], Bp: V3 = [DP[0], WY + 0.05, DP[2]], dx = Bp[0] - A[0], dz = Bp[2] - A[2], L = Math.hypot(dx, dz), yaw = Math.atan2(-dz, dx);
  const smile = t > 16.33, wave = t > 16.4 && t < 18.6, wK = seg(t, 16.4, 16.6) * (1 - seg(t, 18.4, 18.6));
  const thK = seg(t, 16.95, 17.25, Easing.out(Easing.back(2)));
  return (<>
    <Cam t={t} keys={K4} />
    <PoolWorld t={t} f={f} over={{ dad: { mood: smile ? (t > 17.3 ? "laugh" : "grin") : "smile", lookX: 1, armR: wave ? [0.28 + 0.05 * Math.sin(f * 0.6), 0.86] : [0.22, 0.42], armRK: wave ? wK : 1 } }} />
    <PopSign p={camSpace([bs.x, bs.y + HB * 0.62, bs.z], camAt(t, K4).pos, 0.25, -0.62, 0.75)} s={0.8} k={waveK} draw={(c, W, H) => iconBadge(c, W, H, () => drawHand(c, W, H))} />
    <PopSign p={camSpace([bs.x, bs.y + HB * 0.62, bs.z], camAt(t, K4).pos, 0.25, 0.62, 0.75)} s={0.8} k={yellK} draw={(c, W, H) => iconBadge(c, W, H, () => drawYell(c, W, H))} />
    {/* measuring tape on the water: boy -> father */}
    {tapeK > 0 ? <group position={A} rotation={[0, yaw, 0]}><CanvasPlane p={[L * tapeK / 2, 0, 0]} rot={[-Math.PI / 2, 0, 0]} s={[L * tapeK + 0.01, 0.32]} px={[512, 32]} draw={(c, W, H) => { c.fillStyle = "#ffd23a"; c.fillRect(0, 0, W, H); c.fillStyle = INK; for (let x = 0; x < W; x += 16) c.fillRect(x, 0, 3, x % 64 ? 10 : 20); c.strokeStyle = INK; c.lineWidth = 4; c.strokeRect(1, 1, W - 2, H - 2); }} />
      <Box p={[L * tapeK, 0.12, 0]} s={[0.4, 0.3, 0.4]} color="#ffd23a" line={2} /></group> : null}
    <PopSign p={[(A[0] + Bp[0]) / 2 + 0.4, 0.75, (A[2] + Bp[2]) / 2]} s={1.25} k={labK} draw={(c, W, H) => { c.fillStyle = "#ffd23a"; c.strokeStyle = INK; c.lineWidth = 10; c.beginPath(); c.roundRect(W * 0.08, H * 0.25, W * 0.84, H * 0.5, 30); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 104px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("3 m", W / 2, H / 2 + 6); }} />
    {/* what the father thinks he sees */}
    <Thought p={camSpace([DP[0], DP[1] + HD * 0.8, DP[2]], camAt(t, K4).pos, 0.1, 1.05, 1.25)} s={[2.6, 2.0]} k={thK} tail={-1} draw={(c, W, H) => {
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#bfeaff"); g.addColorStop(1, "#3fb6e6"); c.fillStyle = g; c.fillRect(0, 0, W, H);
      const bx = W * 0.5, by = H * 0.48 + Math.sin(f * 0.3) * 4; c.strokeStyle = INK; c.lineWidth = 7; c.fillStyle = "#ffe14d"; c.beginPath(); c.ellipse(bx, by + H * 0.28, W * 0.13, H * 0.2, 0, 0, 7); c.fill(); c.stroke();
      c.fillStyle = "#f7d4b5"; c.beginPath(); c.arc(bx, by, W * 0.12, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.arc(bx, by + 4, W * 0.07, 0.3, Math.PI - 0.3); c.stroke();
      c.fillStyle = INK; c.beginPath(); c.arc(bx - W * 0.04, by - 6, 5, 0, 7); c.arc(bx + W * 0.04, by - 6, 5, 0, 7); c.fill();
      for (const s of [-1, 1]) { c.beginPath(); c.moveTo(bx + s * W * 0.1, by + H * 0.2); c.lineTo(bx + s * W * 0.24, by - H * 0.08 + Math.sin(f * 0.5 + s) * 6); c.stroke(); }
      c.fillStyle = "#e5233a"; c.beginPath(); c.arc(W * 0.82, H * 0.28 + Math.abs(Math.sin(f * 0.2)) * -14, W * 0.07, 0, 7); c.fill(); c.stroke();
      c.fillStyle = "rgba(255,255,255,.9)"; c.fillRect(0, H * 0.78, W, H * 0.22); c.strokeStyle = "#1d7fc0"; c.lineWidth = 6; c.beginPath(); for (let x = 0; x <= W; x += 10) c.lineTo(x, H * 0.78 + Math.sin(x * 0.08 + f * 0.3) * 6); c.stroke();
      c.fillStyle = "#e5233a"; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.fillText("♥", W * 0.18, H * 0.3);
    }} />
  </>);
};

/* =================== S5 18.68 – 20.33  "Maya is already in the air." =================== */
const K5: Key[] = (() => { const ks: Key[] = []; for (let tt = 18.3; tt <= 20.7; tt += 0.25) { const m = mayaState(Math.min(tt, 19.75)); const c: V3 = [m.p[0] + Math.sin(m.tilt) * 0.5 * HM, m.p[1] + Math.cos(m.tilt) * 0.5 * HM, m.p[2]]; ks.push({ t: tt, pos: [c[0] * 0.5 - 2.6, 2.4, 2.0], look: [c[0] + 0.3, c[1] - 0.2, c[2]], fov: 56 }); } return ks; })();
const S5 = ({ t, f }: Ctx) => {
  const trail = Array.from({ length: 7 }, (_, k) => { const tt = t - (k + 1) * 0.035; if (tt < 18.6 || tt > 19.66) return null; const m = mayaState(tt), hp = m.p; return <Glow key={k} p={[hp[0] + Math.sin(m.tilt) * 1.6, hp[1] + Math.cos(m.tilt) * 1.6, hp[2]]} r={0.9 - k * 0.1} color="rgba(255,255,255,1)" o={0.45 - k * 0.05} />; });
  return (<>
    <Cam t={t} keys={K5} impacts={[[19.6, 0.03]]} />
    <PoolWorld t={t} f={f} />
    {trail}
  </>);
};

/* =================== studio tank (S6 + S7) =================== */
const TW = 4.6, TH = 3.2;
const tankBoyY = (t: number) => TW - 0.575 * TH + 0.06 * Math.sin(t * 5.2 + 0.6) + 0.05 * Math.sin(t * 5.2);
const Tank: React.FC<{ t: number; f: number; boy: PoseIn; red?: boolean }> = ({ t, f, boy, red }) => (<>
  <Floor kind="marble" a={red ? "#1a1240" : "#16206a"} b={red ? "#140e36" : "#121a58"} unit={2.6} w={60} d={60} />
  <Surface p={[0, 10, -10]} s={[60, 24]} kind="tile" a={red ? "#22104a" : "#1a2a7a"} b={red ? "#1c0d40" : "#16246c"} unit={2} />
  {Array.from({ length: 30 }, (_, i) => <Glow key={"led" + i} p={[-14 + (i % 10) * 3.1, 4 + Math.floor(i / 10) * 3.4, -9.8]} r={0.35} color={red ? "rgba(255,90,90,1)" : "rgba(120,200,255,1)"} o={0.35 + 0.25 * Math.sin(t * 2 + i)} />)}
  <Box p={[0, 0.3, 0]} s={[7.2, 0.6, 3.8]} color="#2b3350" />
  <Box p={[0, 0.66, 1.95]} s={[7.2, 0.12, 0.1]} color="#ffd23a" line={2} />
  {/* tank interior tiles */}
  <TilePlane p={[0, 3.4, -1.48]} s={[6, 5.6]} t={t} a="#3fb6e6" b="#36a8dc" stripe={undefined} />
  <TilePlane p={[0, 0.63, 0]} s={[6, 3]} rot={[-Math.PI / 2, 0, 0]} t={t} />
  <TilePlane p={[-2.98, 3.4, 0]} s={[3, 5.6]} rot={[0, Math.PI / 2, 0]} t={t} caustic={0.5} a="#38aede" b="#30a2d6" />
  <TilePlane p={[2.98, 3.4, 0]} s={[3, 5.6]} rot={[0, -Math.PI / 2, 0]} t={t} caustic={0.5} a="#38aede" b="#30a2d6" />
  {/* bubbles rising in the corners */}
  {Array.from({ length: 10 }, (_, i) => { const u = (t * 0.35 + i * 0.13) % 1; const yb = 0.9 + u * (TW - 1.0); return <Ball key={"b" + i} p={[(i % 2 ? -2.4 : 2.4) + Math.sin(t * 3 + i) * 0.1, yb, -0.9 + (i % 3) * 0.5]} r={0.07 + (i % 3) * 0.03} color="#e8fbff" ink={0.02} />; })}
  {/* the boy, treading (legs cycle like climbing a ladder) */}
  <Person p={[0, tankBoyY(t), 0]} sy={0.63} h={TH} look={boyLook} f={f} pose={boy} />
  {/* water body */}
  <Water t={t} x0={-3} x1={3} z0={-1.5} z1={1.5} y={TW} o={0.5} />
  <WaterFace p={[0, (0.62 + TW) / 2, 1.5]} s={[6, TW - 0.62]} />
  <WaterFace p={[-3, (0.62 + TW) / 2, 0]} s={[3, TW - 0.62]} rot={[0, Math.PI / 2, 0]} />
  <WaterFace p={[3, (0.62 + TW) / 2, 0]} s={[3, TW - 0.62]} rot={[0, Math.PI / 2, 0]} />
  <Glass p={[0, (TW + 6.2) / 2, 1.5]} s={[6, 6.2 - TW]} />
  {/* glass frame */}
  {[[-3.05, 1.55], [3.05, 1.55], [-3.05, -1.55], [3.05, -1.55]].map(([x, z], i) => <Box key={"v" + i} p={[x, 3.4, z]} s={[0.12, 5.6, 0.12]} color="#c8d2e8" line={2} />)}
  {[0.62, 6.2].map((y) => <React.Fragment key={"h" + y}><Box p={[0, y, 1.55]} s={[6.2, 0.12, 0.12]} color="#c8d2e8" line={2} /><Box p={[0, y, -1.55]} s={[6.2, 0.12, 0.12]} color="#c8d2e8" line={2} /><Box p={[-3.05, y, 0]} s={[0.12, 0.12, 3.2]} color="#c8d2e8" line={2} /><Box p={[3.05, y, 0]} s={[0.12, 0.12, 3.2]} color="#c8d2e8" line={2} /></React.Fragment>)}
  {/* studio dressing */}
  <SpotCone p={[0, 13, 0.4]} h={12.4} r={3.8} color={red ? "#ffb0b0" : "#d8f4ff"} o={0.1} />
  {[-1, 1].map((s) => <group key={"ls" + s} position={[s * 8.2, 0, -2.5]}><Cyl p={[0, 2.6, 0]} rt={0.08} h={5.2} color="#2b3350" line={2} /><Box p={[0, 5.4, 0.2]} s={[1.1, 0.8, 0.6]} rot={[0.3, -s * 0.5, 0]} color="#1b1b2a" /><Glow p={[-s * 0.3, 5.3, 0.7]} r={1.4} color="rgba(255,240,200,1)" o={0.55} />{[-1, 1].map((q) => <Box key={q} p={[q * 0.7, 0.1, 0.4 * q]} s={[1.4, 0.08, 0.08]} rot={[0, q * 0.6, 0]} color="#2b3350" line={1} />)}</group>)}
  <Monitor p={[-7.6, 0, 3.2]} rot={[0, 0.5, 0]} screen={red ? "#ff3b4b" : "#2fd46a"} /><Monitor p={[7.6, 0, 3.2]} rot={[0, -0.5, 0]} screen="#1d6f7f" />
  <Lamp p={[-10.5, 0, -6]} h={3.4} color="#cdf6ff" /><Lamp p={[10.5, 0, -6]} h={3.4} color="#cdf6ff" />
  <Box p={[-6, 0.03, 4.5]} s={[5, 0.04, 0.12]} rot={[0, 0.4, 0]} color="#0b0d1a" line={1} /><Box p={[6, 0.03, 4.2]} s={[5, 0.04, 0.12]} rot={[0, -0.3, 0]} color="#0b0d1a" line={1} />
  <Glow p={[0, 0.7, 2.2]} r={3.6} color={red ? "rgba(255,60,80,1)" : "rgba(80,200,255,1)"} o={0.25} />
  <Dust t={t} area={[6, 8, 3]} color="rgba(200,240,255,.9)" />
</>);
const pressPose = (t: number, k = 1): PoseIn => ({ mood: "gasp", headUp: 1, armR: [0.4, 0.46 - 0.06 * Math.sin(t * 5.2) * k], armL: [-0.4, 0.46 - 0.06 * Math.sin(t * 5.2 + 0.5) * k], walk: t * 4, speed: 0.35 });

/* =================== S6 20.33 – 26.55  "This is the Instinctive Drowning Response. A drowning body spends every breath on breathing, so there is nothing left to scream with." =================== */
const K6: Key[] = [
  { t: 20.13, pos: [0, 7.4, 19], look: [0, 7.4, -3], fov: 56 },
  { t: 22.0, pos: [0, 6.6, 16.5], look: [0, 6.4, -3], fov: 56 },
  { t: 23.1, pos: [-2.4, 5.4, 11.0], look: [-0.8, 4.6, 0], fov: 54 },
  { t: 24.6, pos: [-3.6, 5.6, 11.4], look: [-2.2, 5.0, 0], fov: 54 },
  { t: 25.6, pos: [0, 6.2, 20.5], look: [0, 4.9, 0], fov: 56 },
  { t: 26.85, pos: [0.3, 6.2, 20.0], look: [0.2, 4.9, 0], fov: 56 },
];
const BREATHS = [22.62, 23.03, 23.69, 24.01, 24.45];
const GL: V3 = [-4.0, 0, 1.6], GR: V3 = [4.0, 0, 1.6], GH = 5.0;
const S6 = ({ t, f }: Ctx) => {
  const drop = seg(t, 20.45, 20.95, Easing.out(Easing.back(1.6))), boardY = lerp(17, 9.8, drop);
  const lines = [20.99, 21.53, 21.91].map((a) => seg(t, a, a + 0.22, Easing.out(Easing.back(2.6))));
  const mouth: V3 = [0, TW + 0.15, 0.3], top: V3 = [GL[0], GH + 0.6, GL[2]];
  const fill = BREATHS.reduce((s, b) => s + 0.2 * seg(t, b + 0.45, b + 0.65), 0);
  const zero = seg(t, 25.37, 25.6, Easing.out(Easing.back(2.6))), blink = t > 25.37 && Math.sin(f * 0.8) > -0.3;
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#e0f4ff" />
    <Tank t={t} f={f} boy={{ ...pressPose(t), lookX: t > 22.6 && t < 24.8 ? -0.8 : 0 }} />
    {/* title board on cables */}
    {[-4.6, 4.6].map((x) => <Cyl key={x} p={[x, (boardY + 2.1 + 20) / 2, -4]} rt={0.03} h={20 - boardY - 2.1} color="#9aa0b8" line={1} />)}
    <group position={[0, boardY, -4]} rotation={[0, 0, Math.sin(t * 4) * 0.02 * (1 - seg(t, 20.9, 21.8))]}>
      <Box p={[0, 0, -0.15]} s={[11.4, 4.4, 0.25]} color="#0b0d1a" />
      <CanvasPlane p={[0, 0, 0.0]} s={[11, 4]} px={[1100, 400]} draw={(c, W, H) => {
        const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#ff3b4b"); g.addColorStop(1, "#b5122e"); c.fillStyle = g; c.fillRect(0, 0, W, H);
        c.strokeStyle = "#ffd23a"; c.lineWidth = 12; c.strokeRect(14, 14, W - 28, H - 28);
        const txt = ["INSTINCTIVE", "DROWNING", "RESPONSE"]; c.textAlign = "center"; c.textBaseline = "middle";
        txt.forEach((s, i) => { const k = lines[i]; if (k <= 0.01) return; c.save(); c.translate(W / 2, 78 + i * 122); c.scale(0.6 + 0.4 * k, 0.6 + 0.4 * k); c.globalAlpha = clamp(k * 1.5); c.font = "900 118px Inter, Arial"; c.lineWidth = 14; c.strokeStyle = INK; c.strokeText(s, 0, 4); c.fillStyle = i === 1 ? "#ffd23a" : "#ffffff"; c.fillText(s, 0, 4); c.restore(); });
      }} />
    </group>
    {/* breath gauges */}
    <Gauge p={GL} h={GH} r={0.6} fill={fill} color="#5fd8ff" label="BREATHE" />
    <Gauge p={GR} h={GH} r={0.6} fill={0} color="#ff3b4b" label="SCREAM" labelBg={t > 25.37 && blink ? "#e5233a" : "#1b2a5a"} />
    <PopSign p={[GR[0], GH * 0.5 + 0.4, GR[2] + 0.9]} s={1.9} k={zero} draw={(c, W, H) => { c.fillStyle = "#ffffff"; c.strokeStyle = INK; c.lineWidth = 10; c.beginPath(); c.arc(W / 2, H / 2, W * 0.42, 0, 7); c.fill(); c.stroke(); c.fillStyle = "#e5233a"; c.font = "900 110px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("0%", W / 2, H / 2 + 6); }} />
    {/* breath tokens: mouth -> BREATHE tube */}
    {BREATHS.map((b, i) => { const u = clamp((t - b) / 0.5); if (t < b || t > b + 0.55) return null; const e = Easing.inOut(Easing.sin)(u);
      const p: V3 = [lerp(mouth[0], top[0], e), lerp(mouth[1], top[1], e) + Math.sin(e * Math.PI) * 1.8, lerp(mouth[2], top[2], e)];
      return <React.Fragment key={i}><Ball p={p} r={0.26} color="#bff3ff" ink={0.04} /><Glow p={p} r={0.8} color="rgba(140,230,255,1)" o={0.6} /></React.Fragment>; })}
  </>);
};

/* =================== S7 26.55 – 29.75  "The arms press down on the water to lift the mouth, so they can't wave." =================== */
const K7: Key[] = [
  { t: 26.35, pos: [3.4, 4.75, 6.6], look: [0, 4.3, 0], fov: 50 },
  { t: 28.0, pos: [2.0, 4.8, 5.8], look: [0, 4.5, 0], fov: 46 },
  { t: 29.95, pos: [1.1, 5.0, 6.3], look: [0, 4.7, 0], fov: 46 },
];
const S7 = ({ t, f }: Ctx) => {
  const press = seg(t, 26.95, 27.15, Easing.out(Easing.back(2.2))), lift = seg(t, 28.1, 28.32, Easing.out(Easing.back(2.2))), nope = seg(t, 28.8, 29.0, Easing.out(Easing.back(2.4)));
  const pulse = Math.max(0, Math.sin(t * 5.2));
  const fy = tankBoyY(t);
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#ffc8b8" />
    <Tank t={t} f={f} red boy={{ ...pressPose(t, 1.6), lookX: 0 }} />
    {press > 0 ? [-1, 1].map((s) => <Arrow3D key={s} p={[s * 1.25, fy + 0.95 - 0.25 * pulse, 0.5]} rot={[0, 0, Math.PI]} L={1.4 * press} color="#2fd46a" depth={0.22} />) : null}
    {lift > 0 ? <Arrow3D p={[0.0, TW + 1.35 + 0.12 * pulse, 0.55]} L={1.3 * lift} color="#ffd23a" depth={0.22} /> : null}
    <PopSign p={[1.05, 5.8, 1.62]} s={0.95} k={nope} draw={(c, W, H) => iconBadge(c, W, H, () => drawHand(c, W, H))} />
  </>);
};

/* =================== S8 29.75 – 34.05  "From the outside, it looks calm. It lasts twenty to sixty seconds before they go under." =================== */
const K8: Key[] = [
  { t: 29.55, pos: [0.5, 24, 8], look: [0.5, -1, -5], fov: 56 },
  { t: 31.3, pos: [0.8, 11, 4], look: [0.8, 0, -10], fov: 56 },
  { t: 32.7, pos: [1.2, 2.2, -0.6], look: [0.7, 0.6, -15.5], fov: 54 },
  { t: 34.3, pos: [1.2, 1.6, -1.6], look: [0.7, 0.3, -15.5], fov: 52 },
];
const S8 = ({ t, f }: Ctx) => {
  const bandK = seg(t, 31.94, 32.1) * 0.0001 + (t < 32.36 ? 0.02 * seg(t, 31.94, 32.1) : 0.02 + 0.98 * seg(t, 32.36, 32.9, Easing.inOut(Easing.cubic)));
  const warn = seg(t, 33.48, 33.7) * (0.6 + 0.4 * Math.sin(f * 0.9));
  return (<>
    <Cam t={t} keys={K8} />
    <PoolWorld t={t} f={f} calm={1 - seg(t, 31.2, 32.4)} clock={{ band: [20, 60], bandK, warn }} />
  </>);
};

/* =================== S9 34.05 – 37.85  "She reaches him at forty. At the wall, he finally coughs, then cries." =================== */
const K9: Key[] = [
  { t: 33.85, pos: [-5.8, 1.9, -12.9], look: [-2.2, 0.1, -8.2], fov: 56 },
  { t: 34.65, pos: [-1.4, 1.8, -12.6], look: [0.6, 0.3, -8.4], fov: 54 },
  { t: 35.9, pos: [3.0, 1.6, -12.4], look: [5.6, 0.4, -8.3], fov: 52 },
  { t: 38.1, pos: [4.0, 1.3, -11.9], look: [5.9, 0.5, -8.4], fov: 46 },
];
const S9 = ({ t, f }: Ctx) => {
  const bs = boyState(t);
  const fortyK = seg(t, 34.7, 34.95, Easing.out(Easing.back(2.6))) * (1 - seg(t, 35.6, 35.85));
  const mouthW: V3 = [bs.x - 0.05, bs.y + HB * 0.52, bs.z + 0.25];
  const spray = Array.from({ length: 9 }, (_, i) => { const t0 = COUGH + (i % 2) * 0.24, dt = t - t0; if (dt < 0 || dt > 0.7) return null; const vx = -1.2 - (i % 3) * 0.5, vy = 1.6 + (i % 4) * 0.5, vz = 0.6 + (i % 2) * 0.4; const y = mouthW[1] + vy * dt - 7 * dt * dt; if (y < WY) return null;
    return <Ball key={i} p={[mouthW[0] + vx * dt, y, mouthW[2] + vz * dt]} r={0.06} color="#dff4ff" ink={0.015} />; });
  return (<>
    <Cam t={t} keys={K9} />
    <PoolWorld t={t} f={f} clock={{ band: [20, 60], bandK: 1 }} />
    <PopSign p={camSpace([bs.x, bs.y + HB, bs.z], camAt(t, K9).pos, 0.3, 0.0, 0.5)} s={0.8} k={fortyK} draw={(c, W, H) => { c.fillStyle = "#e5233a"; c.strokeStyle = INK; c.lineWidth = 10; c.beginPath(); c.roundRect(W * 0.06, H * 0.22, W * 0.88, H * 0.56, 34); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 112px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("0:40", W / 2, H / 2 + 6); }} />
    {spray}
  </>);
};

/* =================== S10 37.85 – 41.73  "His father turns around, confused. Nobody in the whole pool heard a thing." =================== */
const K10: Key[] = [
  { t: 37.65, pos: [8.8, 1.9, -10.6], look: [-1.6, 0.8, -3.0], fov: 50 },
  { t: 39.6, pos: [8.5, 2.1, -10.3], look: [-1.8, 0.7, -2.8], fov: 44 },
  { t: 40.8, pos: [8.0, 9.0, -1.0], look: [-0.5, -0.5, -5.5], fov: 54 },
  { t: 42.1, pos: [3.0, 21, 15], look: [0, -1, -5.5], fov: 58 },
];
const S10 = ({ t, f }: Ctx) => {
  const turn = seg(t, 38.3, 38.72, Easing.inOut(Easing.sin)), conf = t > 38.9;
  return (<>
    <Cam t={t} keys={K10} />
    <PoolWorld t={t} f={f} clock={{ band: [20, 60], bandK: 1 }} over={{ dad: { turn, mood: conf ? "confused" : "shock", q: seg(t, 38.95, 39.2, Easing.out(Easing.back(3))), lookX: conf ? Math.sin(t * 2.4) * 0.8 : 0, armR: conf ? [0.18, 0.66] : [0.22, 0.42], armRK: conf ? seg(t, 38.9, 39.2) : 1, armL: [-0.24, 0.42] } }} />
  </>);
};

const CUTS = [0, 4.05, 7.62, 13.1, 18.68, 20.33, 26.55, 29.75, 34.05, 37.85, 41.74];
export const DROWNING_FRAMES = 1253;
export const Drowning: React.FC = () => {
  const f = useCurrentFrame(), t = f / FPS;
  const tint = t < 4.05 ? "rgba(255,210,120,.05)" : t < 7.62 ? "rgba(255,140,80,.05)" : t < 13.1 ? "rgba(0,120,200,.06)" : t < 18.68 ? "rgba(255,200,90,.05)" : t < 20.33 ? "rgba(255,255,255,.03)" : t < 26.55 ? "rgba(20,40,160,.10)" : t < 29.75 ? "rgba(200,30,60,.10)" : t < 34.05 ? "rgba(0,160,200,.05)" : t < 37.85 ? "rgba(255,170,90,.05)" : "rgba(60,90,200,.06)";
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <Audio src={staticFile("mix.wav")} />
      <Scene first start={CUTS[0]} end={CUTS[1]} bg="#9fdcff">{(c) => <S1 {...c} />}</Scene>
      <Scene start={CUTS[1]} end={CUTS[2]} bg="#9fdcff" trans="zoom">{(c) => <S2 {...c} />}</Scene>
      <Scene start={CUTS[2]} end={CUTS[3]} bg="#9fdcff">{(c) => <S3 {...c} />}</Scene>
      <Scene start={CUTS[3]} end={CUTS[4]} bg="#9fdcff" trans="whip">{(c) => <S4 {...c} />}</Scene>
      <Scene start={CUTS[4]} end={CUTS[5]} bg="#9fdcff" trans="flash">{(c) => <S5 {...c} />}</Scene>
      <Scene start={CUTS[5]} end={CUTS[6]} bg="#0a1440" trans="zoom">{(c) => <S6 {...c} />}</Scene>
      <Scene start={CUTS[6]} end={CUTS[7]} bg="#120a30">{(c) => <S7 {...c} />}</Scene>
      <Scene start={CUTS[7]} end={CUTS[8]} bg="#9fdcff" trans="whip">{(c) => <S8 {...c} />}</Scene>
      <Scene start={CUTS[8]} end={CUTS[9]} bg="#9fdcff">{(c) => <S9 {...c} />}</Scene>
      <Scene start={CUTS[9]} end={CUTS[10]} bg="#9fdcff" trans="zoom">{(c) => <S10 {...c} />}</Scene>
      <Grade t={t} shaft={t < 20.33 || t > 29.75} tint={tint} />
      <Captions />
    </AbsoluteFill>
  );
};
