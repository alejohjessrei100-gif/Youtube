// Pool / water props (added for the "drowning" video). Logged in rules/ACTION-LIBRARY.md.
import React, { useMemo } from "react";
import * as THREE from "three";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3, lerp, clamp } from "./kit";
import { Glow } from "./props";

const ramp = (() => { const d = new Uint8Array([90, 170, 255]); const t = new THREE.DataTexture(d, 3, 1, THREE.RedFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
const useCanvas = (w: number, h: number) => useMemo(() => { const cv = document.createElement("canvas"); cv.width = w; cv.height = h; const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; return { cv, tex }; }, [w, h]);

/* Transparent water surface over [x0,x1]x[z0,z1] at height y. renderOrder 10 => drawn after bodies, so everything below is tinted.
   rings: [x, z, t0] expanding ripple rings (splashes, strokes). */
export const Water: React.FC<{ t: number; x0: number; x1: number; z0: number; z1: number; y: number; rings?: [number, number, number][]; color?: string; o?: number; calm?: number }> = ({ t, x0, x1, z0, z1, y, rings = [], color = "30,176,226", o = 0.6, calm = 0 }) => {
  const W = 512, H = Math.max(64, Math.round(512 * (z1 - z0) / (x1 - x0)));
  const { cv, tex } = useCanvas(W, H); const c = cv.getContext("2d")!;
  c.clearRect(0, 0, W, H); c.fillStyle = `rgba(${color},${o})`; c.fillRect(0, 0, W, H);
  c.lineCap = "round"; const amp = 1 - calm * 0.6;
  for (let i = 0; i < 40; i++) {
    const yy = ((i * 61) % H) + Math.sin(t * 0.7 + i) * 6; c.strokeStyle = `rgba(255,255,255,${0.5 * amp + 0.15})`; c.lineWidth = 3; c.beginPath(); let on = false;
    for (let x = 0; x <= W; x += 6) { const v = Math.sin(x * 0.045 + i * 1.9 + t * 1.6) + Math.sin(x * 0.013 - t * 0.9 + i); const py = yy + Math.sin(x * 0.03 + t * 2.2 + i) * 5 * amp;
      if (v > 0.9) { if (!on) { c.moveTo(x, py); on = true; } else c.lineTo(x, py); } else if (on) { c.stroke(); c.beginPath(); on = false; } }
    if (on) c.stroke();
  }
  const ppu = W / (x1 - x0);
  for (const [rx, rz, t0] of rings) { const u = (t - t0) / 1.4; if (u < 0 || u > 1.3) continue; const cx = (rx - x0) * ppu, cy = (rz - z0) * ppu;
    for (let k = 0; k < 3; k++) { const uu = u - k * 0.14; if (uu <= 0 || uu > 1) continue; c.strokeStyle = `rgba(255,255,255,${0.9 * (1 - uu)})`; c.lineWidth = 6 * (1 - uu) + 1; c.beginPath(); c.ellipse(cx, cy, uu * ppu * 1.5 + 3, uu * ppu * 1.5 + 3, 0, 0, 7); c.stroke(); } }
  tex.needsUpdate = true;
  return <mesh position={[(x0 + x1) / 2, y, (z0 + z1) / 2]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={10}><planeGeometry args={[x1 - x0, z1 - z0]} /><meshBasicMaterial map={tex} transparent depthWrite={false} side={THREE.DoubleSide} /></mesh>;
};
// vertical water body face (aquarium / cutaway glass), tints what is behind it
export const WaterFace: React.FC<{ p: V3; s: [number, number]; rot?: V3; color?: string; o?: number }> = ({ p, s, rot = [0, 0, 0], color = "#1ea6e0", o = 0.42 }) => (
  <mesh position={p} rotation={rot} renderOrder={10}><planeGeometry args={s} /><meshBasicMaterial color={color} transparent opacity={o} depthWrite={false} side={THREE.DoubleSide} /></mesh>
);
export const Glass: React.FC<{ p: V3; s: [number, number]; rot?: V3; o?: number }> = ({ p, s, rot = [0, 0, 0], o = 0.08 }) => (
  <mesh position={p} rotation={rot} renderOrder={11}><planeGeometry args={s} /><meshBasicMaterial color="#e8f8ff" transparent opacity={o} depthWrite={false} side={THREE.DoubleSide} /></mesh>
);

/* Pool tiles with animated caustics (floors / walls). */
export const TilePlane: React.FC<{ p: V3; s: [number, number]; rot?: V3; t: number; a?: string; b?: string; unit?: number; caustic?: number; stripe?: string }> = ({ p, s, rot = [0, 0, 0], t, a = "#4cc9ef", b = "#3fbbe6", unit = 0.8, caustic = 1, stripe }) => {
  const W = 256, H = Math.max(32, Math.round(256 * s[1] / s[0])); const { cv, tex } = useCanvas(W, H); const c = cv.getContext("2d")!;
  const nx = Math.max(1, Math.round(s[0] / unit)), ny = Math.max(1, Math.round(s[1] / unit)), cw = W / nx, ch = H / ny;
  for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { c.fillStyle = (i + j) % 2 ? a : b; c.fillRect(i * cw, j * ch, cw + 1, ch + 1); }
  c.strokeStyle = "rgba(10,40,90,.45)"; c.lineWidth = 1.5;
  for (let i = 0; i <= nx; i++) { c.beginPath(); c.moveTo(i * cw, 0); c.lineTo(i * cw, H); c.stroke(); }
  for (let j = 0; j <= ny; j++) { c.beginPath(); c.moveTo(0, j * ch); c.lineTo(W, j * ch); c.stroke(); }
  if (stripe) { c.fillStyle = stripe; for (const fx of [0.25, 0.5, 0.75]) c.fillRect(W * fx - cw * 0.35, ch, cw * 0.7, H - 2 * ch); }
  if (caustic > 0) { c.strokeStyle = `rgba(255,255,255,${0.34 * caustic})`; c.lineWidth = 2.2;
    for (let k = 0; k < 26; k++) { const cx = (k * 97) % W, cy = (k * 53 + k * k * 7) % H; c.beginPath();
      for (let q = 0; q <= 10; q++) { const a2 = q / 10 * Math.PI * 2, r = 12 + 6 * Math.sin(t * 2 + k + q * 1.3); const x = cx + Math.cos(a2) * r * 1.4 + Math.sin(t * 0.8 + k) * 8, y = cy + Math.sin(a2) * r; q ? c.lineTo(x, y) : c.moveTo(x, y); }
      c.stroke(); } }
  tex.needsUpdate = true;
  return <mesh position={p} rotation={rot}><planeGeometry args={s} /><meshBasicMaterial map={tex} /></mesh>;
};

/* Splash: ballistic droplets + white crown column, from t0 (y of p = water level). */
export const Splash: React.FC<{ p: V3; t: number; t0: number; n?: number; power?: number }> = ({ p, t, t0, n = 16, power = 1 }) => {
  const dt = t - t0; if (dt < 0 || dt > 1.4) return null; const g = 14;
  const crown = dt < 0.45 ? Math.sin(dt / 0.45 * Math.PI) : 0;
  return (<>
    {Array.from({ length: n }, (_, i) => { const a = i * 2.399, sp = (0.9 + ((i * 37) % 10) / 10) * 1.7 * power, vy = (3.2 + ((i * 53) % 10) / 10 * 3.2) * Math.sqrt(power);
      const x = p[0] + Math.cos(a) * sp * dt, z = p[2] + Math.sin(a) * sp * dt * 0.8, y = p[1] + vy * dt - 0.5 * g * dt * dt; if (y < p[1] - 0.05) return null;
      return <Ball key={i} p={[x, y, z]} r={(0.07 + ((i * 7) % 5) * 0.025) * Math.sqrt(power)} color="#e6f7ff" ink={0.02} />; })}
    {crown > 0.02 ? Array.from({ length: 10 }, (_, i) => { const a = i / 10 * Math.PI * 2, rr = 0.35 * power + dt * 1.5, hh = 0.55 * power * crown * (0.7 + 0.3 * Math.sin(i * 3.7));
      return <Ball key={"c" + i} p={[p[0] + Math.cos(a) * rr, p[1] + hh * 0.5, p[2] + Math.sin(a) * rr * 0.8]} r={0.13 * Math.sqrt(power)} s={[1, Math.max(1, hh / (0.13 * Math.sqrt(power))), 1]} color="#e6f7ff" ink={0.02} />; }) : null}
  </>);
};

/* outlined torus (swim ring / life ring) with stripes */
export const Torus: React.FC<{ p: V3; R: number; r: number; color: string; stripe?: string; rot?: V3 }> = ({ p, R, r, color, stripe = "#ffffff", rot = [Math.PI / 2, 0, 0] }) => {
  const tex = useMemo(() => { const c = document.createElement("canvas"); c.width = 256; c.height = 16; const g = c.getContext("2d")!; for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? stripe : color; g.fillRect(i * 32, 0, 32, 16); } const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }, [color, stripe]);
  return <group position={p} rotation={rot}><mesh><torusGeometry args={[R, r, 16, 48]} /><meshToonMaterial map={tex} gradientMap={ramp} /></mesh><mesh><torusGeometry args={[R, r + 0.05, 12, 48]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></mesh></group>;
};
export const BeachBall: React.FC<{ p: V3; r?: number; spin?: number }> = ({ p, r = 0.42, spin = 0 }) => {
  const tex = useMemo(() => { const c = document.createElement("canvas"); c.width = 256; c.height = 128; const g = c.getContext("2d")!; const cols = ["#e5233a", "#ffffff", "#2f8cff", "#ffd23a", "#ffffff", "#2fd46a"]; for (let i = 0; i < 6; i++) { g.fillStyle = cols[i]; g.fillRect(i * 256 / 6, 0, 256 / 6 + 1, 128); } g.fillStyle = "#fff"; g.fillRect(0, 0, 256, 10); g.fillRect(0, 118, 256, 10); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }, []);
  return <group position={p} rotation={[spin * 0.7, spin, 0.3]}><mesh><sphereGeometry args={[r, 32, 20]} /><meshToonMaterial map={tex} gradientMap={ramp} /></mesh><mesh><sphereGeometry args={[r + 0.04, 24, 16]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></mesh></group>;
};

/* deck dressing */
export const Palm: React.FC<{ p: V3; h?: number; lean?: number; rotY?: number }> = ({ p, h = 7, lean = 0.18, rotY = 0 }) => {
  const top: V3 = [Math.sin(lean) * h * 0.9, h, 0];
  return (<group position={p} rotation={[0, rotY, 0]}>
    {Array.from({ length: 7 }, (_, i) => { const y = (i + 0.5) * h / 7; return <Cyl key={i} p={[Math.sin(lean) * y * y / h * 0.9, y, 0]} rt={0.2 - i * 0.012} rb={0.25 - i * 0.012} h={h / 7 + 0.06} color={i % 2 ? "#a0703e" : "#8a5a2e"} line={2} rot={[0, 0, -lean * y / h * 1.8]} />; })}
    <group position={top}>{Array.from({ length: 8 }, (_, i) => <group key={i} rotation={[0, i / 8 * Math.PI * 2, 0]}><group position={[1.25, -0.3, 0]} rotation={[0, 0, -0.5]}><Ball p={[0, 0, 0]} r={1} s={[1.6, 0.14, 0.42]} color={i % 2 ? "#2fae4a" : "#24963c"} ink={0.04} /></group></group>)}
      <Ball p={[0.15, -0.25, 0.12]} r={0.22} color="#6a4220" /><Ball p={[-0.15, -0.3, -0.05]} r={0.2} color="#6a4220" /></group>
  </group>);
};
export const Lounger: React.FC<{ p: V3; rotY?: number; color?: string; towel?: string }> = ({ p, rotY = 0, color = "#ffffff", towel }) => (
  <group position={p} rotation={[0, rotY, 0]}>
    <Box p={[0, 0.45, 0.3]} s={[1.0, 0.14, 2.4]} color={color} line={2} /><Box p={[0, 0.85, -1.2]} s={[1.0, 0.14, 1.1]} color={color} rot={[0.9, 0, 0]} line={2} />
    {[[-0.42, 1.2], [0.42, 1.2], [-0.42, -0.7], [0.42, -0.7]].map(([x, z], i) => <Box key={i} p={[x, 0.2, z]} s={[0.08, 0.4, 0.08]} color="#9aa0b8" line={1} />)}
    {towel ? <Box p={[0, 0.54, 0.4]} s={[0.8, 0.04, 1.7]} color={towel} line={2} /> : null}
  </group>
);
export const Umbrella: React.FC<{ p: V3; color?: string; h?: number; r?: number }> = ({ p, color = "#ff5a3a", h = 3.6, r = 2 }) => (
  <group position={p}><Cyl p={[0, h / 2, 0]} rt={0.05} h={h} color="#f2f2f2" line={1} /><Cyl p={[0, h + 0.3, 0]} rt={0.08} rb={r} h={0.7} color={color} /><Cyl p={[0, h - 0.08, 0]} rt={r} rb={r} h={0.1} color="#ffffff" line={2} /><Ball p={[0, h + 0.7, 0]} r={0.1} color="#fff" /></group>
);
// lifeguard tower: platform top at y = 3.08, faces local +z
export const GuardChair: React.FC<{ p: V3; rotY?: number }> = ({ p, rotY = 0 }) => (
  <group position={p} rotation={[0, rotY, 0]}>
    {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([x, z], i) => <Box key={i} p={[x * 0.88, 1.5, z * 0.78]} s={[0.16, 3.0, 0.16]} color="#ffffff" rot={[z * 0.07, 0, -x * 0.07]} line={2} />)}
    {[0.7, 1.4, 2.1].map((y) => <Box key={y} p={[0, y, 0.9]} s={[1.9, 0.1, 0.12]} color="#ffffff" line={2} />)}
    <Box p={[0, 3.0, 0]} s={[2.0, 0.16, 1.8]} color="#e5233a" />
    <CanvasPlane p={[0, 2.55, 0.95]} s={[1.7, 0.6]} px={[340, 120]} frame="#ffffff" draw={(c, W, H) => { c.fillStyle = "#e5233a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 84px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("GUARD", W / 2, H / 2 + 4); }} />
    {[-1, 1].map((s) => <React.Fragment key={s}><Box p={[s * 0.98, 3.5, 0]} s={[0.08, 0.08, 1.8]} color="#ffffff" line={1} /><Box p={[s * 0.98, 3.28, 0.85]} s={[0.08, 0.5, 0.08]} color="#fff" line={1} /><Box p={[s * 0.98, 3.28, -0.85]} s={[0.08, 0.5, 0.08]} color="#fff" line={1} /></React.Fragment>)}
    <Cyl p={[-0.9, 5.2, -0.8]} rt={0.05} h={4.2} color="#dddddd" line={1} /><Cyl p={[-0.9, 7.5, -0.8]} rt={0.08} rb={1.7} h={0.7} color="#ffd23a" />
    {/* rescue tube leaning on the leg */}
    <Box p={[1.2, 0.8, 0.9]} s={[0.32, 1.6, 0.32]} rot={[0, 0, -0.18]} color="#ff3b2b" line={2} />
  </group>
);
/* Pool pace clock (seconds), faces +z. band = highlighted second range; hand = sec */
export const PaceClock: React.FC<{ p: V3; r: number; sec: number; band?: [number, number]; bandK?: number; warn?: number; label?: string }> = ({ p, r, sec, band, bandK = 0, warn = 0, label = "SECONDS" }) => (
  <group position={p}>
    <Cyl p={[0, 0, -0.14]} rt={r + 0.2} h={0.24} color="#1b2a5a" rot={[Math.PI / 2, 0, 0]} />
    <CanvasPlane p={[0, 0, 0.0]} s={[2 * r, 2 * r]} px={[512, 512]} draw={(c, W, H) => {
      c.clearRect(0, 0, W, H); const cx = W / 2, cy = H / 2, R = W / 2 - 6; c.fillStyle = "#fffdf4"; c.beginPath(); c.arc(cx, cy, R, 0, 7); c.fill();
      if (band && bandK > 0) { const a0 = -Math.PI / 2 + band[0] / 60 * 2 * Math.PI, a1 = -Math.PI / 2 + lerp(band[0], band[1], bandK) / 60 * 2 * Math.PI;
        c.fillStyle = warn > 0 ? `rgba(255,${Math.round(190 - 150 * warn)},60,.9)` : "rgba(255,200,60,.85)"; c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, R * 0.93, a0, a1); c.closePath(); c.fill(); }
      c.strokeStyle = INK; for (let i = 0; i < 60; i++) { const a = i / 60 * Math.PI * 2 - Math.PI / 2, l = i % 5 ? 14 : 32; c.lineWidth = i % 5 ? 3 : 8; c.beginPath(); c.moveTo(cx + Math.cos(a) * (R - 6), cy + Math.sin(a) * (R - 6)); c.lineTo(cx + Math.cos(a) * (R - 6 - l), cy + Math.sin(a) * (R - 6 - l)); c.stroke(); }
      c.fillStyle = INK; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle";
      for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2 - Math.PI / 2; c.fillText(String(i * 5), cx + Math.cos(a) * R * 0.7, cy + Math.sin(a) * R * 0.7 + 2); }
      c.font = "800 30px Inter, Arial"; c.fillStyle = "#2f4a8a"; c.fillText(label, cx, cy + R * 0.38);
      const a = clamp(sec, 0, 60) / 60 * Math.PI * 2 - Math.PI / 2; c.strokeStyle = "#e5233a"; c.lineWidth = 12; c.lineCap = "round"; c.beginPath(); c.moveTo(cx - Math.cos(a) * 30, cy - Math.sin(a) * 30); c.lineTo(cx + Math.cos(a) * R * 0.86, cy + Math.sin(a) * R * 0.86); c.stroke();
      c.fillStyle = INK; c.beginPath(); c.arc(cx, cy, 16, 0, 7); c.fill(); c.lineWidth = 14; c.strokeStyle = INK; c.beginPath(); c.arc(cx, cy, R - 4, 0, 7); c.stroke();
    }} />
  </group>
);
/* camera-facing pop sign: k = 0..1 pop scale; draw paints the icon */
export const PopSign: React.FC<{ p: V3; s: number; k: number; draw: (c: CanvasRenderingContext2D, W: number, H: number) => void; px?: number }> = ({ p, s, k, draw, px = 256 }) =>
  k <= 0.01 ? null : <CanvasPlane p={p} s={[s * k, s * k]} px={[px, px]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); draw(c, W, H); }} />;
// icon helpers for PopSign
export const iconBadge = (c: CanvasRenderingContext2D, W: number, H: number, fg: () => void, slash = true) => {
  c.fillStyle = "#ffffff"; c.strokeStyle = INK; c.lineWidth = W * 0.05; c.beginPath(); c.arc(W / 2, H / 2, W * 0.44, 0, 7); c.fill(); c.stroke(); fg();
  if (slash) { c.strokeStyle = "#e5233a"; c.lineWidth = W * 0.08; c.beginPath(); c.arc(W / 2, H / 2, W * 0.38, 0, 7); c.stroke(); c.beginPath(); c.moveTo(W * 0.23, H * 0.23); c.lineTo(W * 0.77, H * 0.77); c.stroke(); }
};
export const drawHand = (c: CanvasRenderingContext2D, W: number, H: number) => {
  c.save(); c.translate(W * 0.5, H * 0.56); c.rotate(-0.25); c.fillStyle = "#ffd9b8"; c.strokeStyle = INK; c.lineWidth = W * 0.025;
  for (let i = 0; i < 4; i++) { c.beginPath(); c.roundRect(-W * 0.13 + i * W * 0.068, -H * 0.3, W * 0.058, H * 0.22, W * 0.03); c.fill(); c.stroke(); }
  c.beginPath(); c.roundRect(-W * 0.24, -H * 0.12, W * 0.12, H * 0.08, W * 0.04); c.fill(); c.stroke();
  c.beginPath(); c.roundRect(-W * 0.14, -H * 0.13, W * 0.29, H * 0.24, W * 0.07); c.fill(); c.stroke(); c.restore();
  c.strokeStyle = INK; c.lineWidth = W * 0.022; for (const s of [-1, 1]) { c.beginPath(); c.arc(W * 0.5, H * 0.45, W * 0.27, s > 0 ? -0.6 : Math.PI - 0.1, s > 0 ? 0.1 : Math.PI + 0.6); c.stroke(); }
};
export const drawYell = (c: CanvasRenderingContext2D, W: number, H: number) => {
  c.fillStyle = "#ffd9b8"; c.strokeStyle = INK; c.lineWidth = W * 0.025; c.beginPath(); c.arc(W * 0.42, H * 0.5, W * 0.17, 0, 7); c.fill(); c.stroke();
  c.fillStyle = "#3a1020"; c.beginPath(); c.ellipse(W * 0.47, H * 0.56, W * 0.05, W * 0.07, 0, 0, 7); c.fill();
  c.fillStyle = INK; c.beginPath(); c.arc(W * 0.38, H * 0.45, W * 0.02, 0, 7); c.arc(W * 0.47, H * 0.45, W * 0.02, 0, 7); c.fill();
  c.lineWidth = W * 0.025; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(W * 0.55, H * 0.55, W * (0.1 + k * 0.06), -0.6, 0.6); c.stroke(); }
};
/* thought bubble (camera-facing) with custom content */
export const Thought: React.FC<{ p: V3; s: [number, number]; k: number; draw: (c: CanvasRenderingContext2D, W: number, H: number) => void; tail?: 1 | -1 }> = ({ p, s, k, draw, tail = -1 }) =>
  k <= 0.01 ? null : <CanvasPlane p={p} s={[s[0] * k, s[1] * k]} px={[512, Math.round(512 * s[1] / s[0])]} face draw={(c, W, H) => {
    c.clearRect(0, 0, W, H); c.fillStyle = "#ffffff"; c.strokeStyle = INK; c.lineWidth = 10;
    const cl = (x: number, y: number, r: number) => { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); c.stroke(); };
    const cx = W / 2, cy = H * 0.42; const bumps = 10;
    for (let i = 0; i < bumps; i++) { const a = i / bumps * Math.PI * 2; cl(cx + Math.cos(a) * W * 0.34, cy + Math.sin(a) * H * 0.27, W * 0.11); }
    c.beginPath(); c.ellipse(cx, cy, W * 0.36, H * 0.29, 0, 0, 7); c.fill();
    cl(cx + tail * W * 0.3, H * 0.84, W * 0.045); cl(cx + tail * W * 0.38, H * 0.94, W * 0.028);
    c.save(); c.beginPath(); c.ellipse(cx, cy, W * 0.34, H * 0.27, 0, 0, 7); c.clip(); c.translate(cx - W * 0.34, cy - H * 0.27); draw(c, W * 0.68, H * 0.54); c.restore();
  }} />;
/* vertical glass gauge tube: fill 0..1 */
export const Gauge: React.FC<{ p: V3; h: number; r: number; fill: number; color: string; label: string; labelBg?: string }> = ({ p, h, r, fill, color, label, labelBg = "#1b2a5a" }) => (
  <group position={p}>
    <Cyl p={[0, 0.2, 0]} rt={r + 0.25} h={0.4} color="#2b3350" />
    {fill > 0.005 ? <Cyl p={[0, 0.4 + (h - 0.2) * fill / 2, 0]} rt={r * 0.86} h={(h - 0.2) * fill} color={color} line={2} /> : null}
    {fill > 0.005 ? <Glow p={[0, 0.4 + (h - 0.2) * fill, 0.3]} r={r * 1.6} color="rgba(140,230,255,1)" o={0.5} /> : null}
    <mesh position={[0, 0.4 + h / 2, 0]} renderOrder={11}><cylinderGeometry args={[r, r, h, 32, 1, true]} /><meshBasicMaterial color="#dff6ff" transparent opacity={0.16} depthWrite={false} side={THREE.DoubleSide} /></mesh>
    <Cyl p={[0, 0.4 + h, 0]} rt={r + 0.08} h={0.14} color="#9aa0b8" line={2} /><Cyl p={[0, 0.45, 0]} rt={r + 0.08} h={0.12} color="#9aa0b8" line={2} />
    {[0.25, 0.5, 0.75].map((k) => <Box key={k} p={[r * 0.75, 0.4 + h * k, r * 0.68]} s={[0.25, 0.05, 0.02]} color="#ffffff" line={1} />)}
    <CanvasPlane p={[0, 0.4 + h + 0.55, 0]} s={[2.0, 0.56]} px={[520, 140]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = labelBg; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 84px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(label, W / 2, H / 2 + 4); }} />
  </group>
);
